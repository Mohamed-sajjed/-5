/*
 * خادم محلي خفيف لموقع مؤسسة ملتقى العلم والثقافية.
 * لا يحتاج إلى npm install: يعتمد فقط على Node.js القياسي.
 */
const http = require('node:http');
const fs = require('node:fs/promises');
const path = require('node:path');
const crypto = require('node:crypto');

const ROOT = __dirname;
const PUBLIC_DIR = path.join(ROOT, 'public');
const DATA_DIR = path.join(ROOT, 'data');
const UPLOAD_DIR = path.join(DATA_DIR, 'uploads');
const CONTENT_FILE = path.join(DATA_DIR, 'content.json');
const ADMIN_FILE = path.join(DATA_DIR, 'admin.json');
const PORT = Number(process.env.PORT || 3000);
const INITIAL_ADMIN_USERNAME = process.env.ADMIN_USERNAME || 'sadiq1988';
// كلمة المرور الابتدائية كما طلبها صاحب الموقع. غيّرها من إعدادات الحساب بعد أول دخول.
const INITIAL_ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'sadiq\\@1988';
const SESSION_TTL_MS = 8 * 60 * 60 * 1000;
const MAX_JSON_BYTES = 7 * 1024 * 1024;
const sessions = new Map();

const MIME_TYPES = {
  '.css': 'text/css; charset=utf-8',
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.gif': 'image/gif',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon'
};

function defaultContent() {
  return {
    settings: {
      siteName: 'مؤسسة ملتقى العلم والثقافية',
      tagline: 'معًا نصنع أثرًا معرفيًا وثقافيًا مستدامًا',
      heroTitle: 'العلم والثقافة… مساحة تلتقي فيها الأفكار',
      heroText: 'نعمل على بناء مجتمع واعٍ ومبدع عبر برامج معرفية وأنشطة ثقافية ومراكز قريبة من الناس.',
      logo: '/assets/logo.png',
      heroImage: '/assets/logo.png'
    },
    activities: [
      {
        id: crypto.randomUUID(),
        title: 'الملتقى الثقافي الأسبوعي',
        details: 'جلسة حوارية مفتوحة تجمع المهتمين بالمعرفة والفكر والثقافة.',
        date: 'كل يوم سبت',
        category: 'ثقافي',
        image: '/assets/logo.png'
      },
      {
        id: crypto.randomUUID(),
        title: 'برنامج القراءة الواعية',
        details: 'رحلة قراءة جماعية تناقش الكتب المؤثرة وتحوّل الأفكار إلى ممارسة.',
        date: 'شهريًا',
        category: 'معرفي',
        image: '/assets/logo.png'
      },
      {
        id: crypto.randomUUID(),
        title: 'ورش مهارات الشباب',
        details: 'ورش عملية في التواصل والقيادة والتخطيط لصناعة مبادرات مجتمعية ناجحة.',
        date: 'حسب الإعلان',
        category: 'تدريبي',
        image: '/assets/logo.png'
      }
    ],
    centers: [
      {
        id: crypto.randomUUID(),
        name: 'المركز الثقافي الرئيس',
        city: 'يُحدَّد من لوحة الإدارة',
        details: 'مساحة للقراءة والندوات والبرامج التدريبية واللقاءات المجتمعية.',
        manager: 'إدارة المؤسسة',
        hours: 'السبت–الخميس | 9 ص – 6 م',
        phone: '',
        images: [],
        videos: []
      }
    ],
    gallery: [
      {
        id: crypto.randomUUID(),
        title: 'هوية المؤسسة',
        caption: 'شعار مؤسسة ملتقى العلم والثقافية',
        image: '/assets/logo.png'
      }
    ],
    contact: {
      address: 'أضف عنوان المؤسسة من لوحة الإدارة',
      phone: '',
      whatsapp: '',
      email: '',
      workHours: 'السبت–الخميس | 9 ص – 6 م',
      mapUrl: ''
    },
    messages: []
  };
}

async function ensureDataFiles() {
  await fs.mkdir(UPLOAD_DIR, { recursive: true });
  try { await fs.access(CONTENT_FILE); } catch { await writeJson(CONTENT_FILE, defaultContent()); }
  try { await fs.access(ADMIN_FILE); } catch {
    const salt = crypto.randomBytes(16).toString('hex');
    await writeJson(ADMIN_FILE, {
      username: INITIAL_ADMIN_USERNAME,
      salt,
      passwordHash: hashPassword(INITIAL_ADMIN_PASSWORD, salt)
    });
  }
}

function hashPassword(password, salt) {
  return crypto.scryptSync(password, salt, 64).toString('hex');
}

function secureEqual(first, second) {
  const a = Buffer.from(first, 'hex');
  const b = Buffer.from(second, 'hex');
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

async function readJson(file) {
  return JSON.parse(await fs.readFile(file, 'utf8'));
}

async function writeJson(file, data) {
  const temp = `${file}.${crypto.randomUUID()}.tmp`;
  await fs.writeFile(temp, JSON.stringify(data, null, 2), 'utf8');
  await fs.rename(temp, file);
}

async function getContent() { return readJson(CONTENT_FILE); }
async function saveContent(content) { return writeJson(CONTENT_FILE, content); }

function sendJson(res, status, body, headers = {}) {
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    ...headers
  });
  res.end(JSON.stringify(body));
}

function sendError(res, status, message) { sendJson(res, status, { error: message }); }

function parseCookies(req) {
  return Object.fromEntries((req.headers.cookie || '').split(';').filter(Boolean).map((part) => {
    const index = part.indexOf('=');
    return [part.slice(0, index).trim(), decodeURIComponent(part.slice(index + 1))];
  }));
}

function getSession(req) {
  const token = parseCookies(req).session;
  const session = token && sessions.get(token);
  if (!session) return null;
  if (session.expiresAt < Date.now()) {
    sessions.delete(token);
    return null;
  }
  return { token, ...session };
}

function requireAdmin(req, res) {
  const session = getSession(req);
  if (!session) {
    sendError(res, 401, 'يجب تسجيل الدخول كمسؤول أولًا.');
    return null;
  }
  return session;
}

function makeSession(username) {
  const token = crypto.randomBytes(32).toString('base64url');
  sessions.set(token, { username, expiresAt: Date.now() + SESSION_TTL_MS });
  return token;
}

function sessionCookie(token, clear = false) {
  const maxAge = clear ? 0 : Math.floor(SESSION_TTL_MS / 1000);
  return `session=${encodeURIComponent(token || '')}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${maxAge}`;
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    req.on('data', (chunk) => {
      size += chunk.length;
      if (size > MAX_JSON_BYTES) {
        reject(Object.assign(new Error('الطلب كبير جدًا. الحد الأقصى للصورة 5 ميغابايت.'), { status: 413 }));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => {
      try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}')); }
      catch { reject(Object.assign(new Error('بيانات الطلب غير صالحة.'), { status: 400 })); }
    });
    req.on('error', reject);
  });
}

function text(value, field, max = 2000, required = false) {
  const result = String(value ?? '').trim();
  if (required && !result) throw Object.assign(new Error(`حقل «${field}» مطلوب.`), { status: 400 });
  if (result.length > max) throw Object.assign(new Error(`حقل «${field}» أطول من اللازم.`), { status: 400 });
  return result;
}

function imageUrl(value) {
  const result = text(value, 'الصورة', 500, false);
  if (result && !result.startsWith('/') && !/^https?:\/\//i.test(result)) {
    throw Object.assign(new Error('رابط الصورة غير صالح.'), { status: 400 });
  }
  return result;
}

function imageList(value) {
  let images = value;
  if (typeof images === 'string') {
    try { images = JSON.parse(images || '[]'); } catch { images = []; }
  }
  if (!Array.isArray(images)) return [];
  if (images.length > 30) throw Object.assign(new Error('يمكن إضافة 30 صورة للمركز كحد أقصى.'), { status: 400 });
  return images.map((image) => imageUrl(image)).filter(Boolean);
}

function videoList(value) {
  let videos = value;
  if (typeof videos === 'string') {
    try { videos = JSON.parse(videos || '[]'); } catch { videos = []; }
  }
  if (!Array.isArray(videos)) return [];
  if (videos.length > 20) throw Object.assign(new Error('يمكن إضافة 20 فيديو للمركز كحد أقصى.'), { status: 400 });
  return videos.map((video) => {
    const result = text(video, 'رابط الفيديو', 500, false);
    if (result && !result.startsWith('/') && !/^https?:\/\//i.test(result)) {
      throw Object.assign(new Error('رابط الفيديو غير صالح.'), { status: 400 });
    }
    return result;
  }).filter(Boolean);
}

function normaliseActivity(body) {
  return {
    title: text(body.title, 'عنوان النشاط', 120, true),
    details: text(body.details, 'وصف النشاط', 1200, true),
    date: text(body.date, 'موعد النشاط', 100, true),
    category: text(body.category, 'التصنيف', 60, true),
    image: imageUrl(body.image)
  };
}

function normaliseCenter(body) {
  return {
    name: text(body.name, 'اسم المركز', 120, true),
    city: text(body.city, 'المدينة أو الموقع', 120, true),
    details: text(body.details, 'وصف المركز', 1200, true),
    manager: text(body.manager, 'المسؤول', 120),
    hours: text(body.hours, 'ساعات العمل', 120),
    phone: text(body.phone, 'الهاتف', 60),
    images: imageList(body.images),
    videos: videoList(body.videos)
  };
}

function normaliseGallery(body) {
  return {
    title: text(body.title, 'عنوان الصورة', 120, true),
    caption: text(body.caption, 'وصف الصورة', 500),
    image: imageUrl(body.image) || '/assets/logo.png'
  };
}

function normaliseSettings(body) {
  return {
    siteName: text(body.siteName, 'اسم المؤسسة', 120, true),
    tagline: text(body.tagline, 'العبارة المختصرة', 180, true),
    heroTitle: text(body.heroTitle, 'عنوان الواجهة', 180, true),
    heroText: text(body.heroText, 'نص الواجهة', 1000, true),
    logo: imageUrl(body.logo) || '/assets/logo.png',
    heroImage: imageUrl(body.heroImage) || '/assets/logo.png'
  };
}

function normaliseContact(body) {
  return {
    address: text(body.address, 'العنوان', 300),
    phone: text(body.phone, 'الهاتف', 60),
    whatsapp: text(body.whatsapp, 'واتساب', 60),
    email: text(body.email, 'البريد الإلكتروني', 160),
    workHours: text(body.workHours, 'ساعات العمل', 160),
    mapUrl: externalUrl(body.mapUrl, 'رابط الخريطة')
  };
}

function externalUrl(value, field) {
  const result = text(value, field, 500);
  if (!result) return '';
  try {
    const url = new URL(result);
    if (!['http:', 'https:'].includes(url.protocol)) throw new Error();
    return url.href;
  } catch {
    throw Object.assign(new Error(`حقل «${field}» يجب أن يكون رابطًا يبدأ بـ http أو https.`), { status: 400 });
  }
}

async function handleUpload(req, res) {
  if (!requireAdmin(req, res)) return;
  const body = await readBody(req);
  const dataUrl = text(body.dataUrl, 'ملف الصورة', MAX_JSON_BYTES, true);
  const match = dataUrl.match(/^data:(image\/(?:png|jpeg|webp|gif));base64,([A-Za-z0-9+/=]+)$/);
  if (!match) throw Object.assign(new Error('يُسمح فقط بصور PNG أو JPG أو WEBP أو GIF.'), { status: 400 });
  const buffer = Buffer.from(match[2], 'base64');
  if (!buffer.length || buffer.length > 5 * 1024 * 1024) throw Object.assign(new Error('حجم الصورة يجب ألا يتجاوز 5 ميغابايت.'), { status: 413 });
  const extension = { 'image/png': 'png', 'image/jpeg': 'jpg', 'image/webp': 'webp', 'image/gif': 'gif' }[match[1]];
  const filename = `${Date.now()}-${crypto.randomUUID().slice(0, 8)}.${extension}`;
  await fs.writeFile(path.join(UPLOAD_DIR, filename), buffer);
  sendJson(res, 201, { url: `/uploads/${filename}` });
}

async function handleResource(req, res, pathname, resource, normalise) {
  if (!requireAdmin(req, res)) return;
  const base = `/api/${resource}`;
  const rest = pathname.slice(base.length).replace(/^\//, '');
  const content = await getContent();
  if (!Array.isArray(content[resource])) content[resource] = [];

  if (req.method === 'POST' && !rest) {
    const record = { id: crypto.randomUUID(), ...normalise(await readBody(req)) };
    content[resource].unshift(record);
    await saveContent(content);
    return sendJson(res, 201, { item: record });
  }
  const id = decodeURIComponent(rest);
  const index = content[resource].findIndex((item) => item.id === id);
  if (index < 0) return sendError(res, 404, 'العنصر المطلوب غير موجود.');
  if (req.method === 'PUT') {
    const record = { id, ...normalise(await readBody(req)) };
    content[resource][index] = record;
    await saveContent(content);
    return sendJson(res, 200, { item: record });
  }
  if (req.method === 'DELETE') {
    content[resource].splice(index, 1);
    await saveContent(content);
    return sendJson(res, 200, { ok: true });
  }
  return sendError(res, 405, 'طريقة الطلب غير مدعومة.');
}

async function handleApi(req, res, url) {
  const { pathname } = url;
  if (req.method === 'GET' && pathname === '/api/content') {
    const { messages, ...publicContent } = await getContent();
    return sendJson(res, 200, publicContent);
  }
  if (req.method === 'GET' && pathname === '/api/session') {
    const session = getSession(req);
    return sendJson(res, 200, { authenticated: Boolean(session), username: session?.username || '' });
  }
  if (req.method === 'POST' && pathname === '/api/login') {
    const { username, password } = await readBody(req);
    const admin = await readJson(ADMIN_FILE);
    const valid = text(username, 'اسم المستخدم', 60, true) === admin.username && secureEqual(hashPassword(String(password ?? ''), admin.salt), admin.passwordHash);
    if (!valid) return sendError(res, 401, 'اسم المستخدم أو كلمة المرور غير صحيحة.');
    const token = makeSession(admin.username);
    return sendJson(res, 200, { ok: true, username: admin.username }, { 'Set-Cookie': sessionCookie(token) });
  }
  if (req.method === 'POST' && pathname === '/api/logout') {
    const session = getSession(req);
    if (session) sessions.delete(session.token);
    return sendJson(res, 200, { ok: true }, { 'Set-Cookie': sessionCookie('', true) });
  }
  if (req.method === 'POST' && pathname === '/api/upload') return handleUpload(req, res);
  if (req.method === 'PUT' && pathname === '/api/settings') {
    if (!requireAdmin(req, res)) return;
    const content = await getContent();
    content.settings = normaliseSettings(await readBody(req));
    await saveContent(content);
    return sendJson(res, 200, { settings: content.settings });
  }
  if (req.method === 'PUT' && pathname === '/api/contact') {
    if (!requireAdmin(req, res)) return;
    const content = await getContent();
    content.contact = normaliseContact(await readBody(req));
    await saveContent(content);
    return sendJson(res, 200, { contact: content.contact });
  }
  if (req.method === 'POST' && pathname === '/api/messages') {
    const body = await readBody(req);
    const message = {
      id: crypto.randomUUID(),
      name: text(body.name, 'الاسم', 100, true),
      phone: text(body.phone, 'الهاتف', 60),
      email: text(body.email, 'البريد الإلكتروني', 160),
      message: text(body.message, 'الرسالة', 2000, true),
      createdAt: new Date().toISOString()
    };
    const content = await getContent();
    content.messages = Array.isArray(content.messages) ? content.messages : [];
    content.messages.unshift(message);
    await saveContent(content);
    return sendJson(res, 201, { ok: true });
  }
  if (pathname === '/api/messages') {
    if (!requireAdmin(req, res)) return;
    const content = await getContent();
    if (req.method === 'GET') return sendJson(res, 200, { messages: content.messages || [] });
    return sendError(res, 405, 'طريقة الطلب غير مدعومة.');
  }
  if (req.method === 'DELETE' && pathname.startsWith('/api/messages/')) {
    if (!requireAdmin(req, res)) return;
    const id = decodeURIComponent(pathname.slice('/api/messages/'.length));
    const content = await getContent();
    const index = (content.messages || []).findIndex((item) => item.id === id);
    if (index < 0) return sendError(res, 404, 'الرسالة غير موجودة.');
    content.messages.splice(index, 1);
    await saveContent(content);
    return sendJson(res, 200, { ok: true });
  }
  if (req.method === 'PUT' && pathname === '/api/account') {
    const session = requireAdmin(req, res);
    if (!session) return;
    const body = await readBody(req);
    const admin = await readJson(ADMIN_FILE);
    const oldHash = hashPassword(String(body.currentPassword ?? ''), admin.salt);
    if (!secureEqual(oldHash, admin.passwordHash)) return sendError(res, 401, 'كلمة المرور الحالية غير صحيحة.');
    const username = text(body.username, 'اسم المستخدم', 60, true);
    if (!/^[A-Za-z0-9_.-]{3,60}$/.test(username)) return sendError(res, 400, 'استخدم حروفًا إنجليزية أو أرقامًا أو . _ - في اسم المستخدم.');
    const newPassword = text(body.newPassword, 'كلمة المرور الجديدة', 160, true);
    if (newPassword.length < 8) return sendError(res, 400, 'كلمة المرور الجديدة يجب أن تكون 8 أحرف على الأقل.');
    const salt = crypto.randomBytes(16).toString('hex');
    await writeJson(ADMIN_FILE, { username, salt, passwordHash: hashPassword(newPassword, salt) });
    sessions.set(session.token, { username, expiresAt: Date.now() + SESSION_TTL_MS });
    return sendJson(res, 200, { ok: true, username });
  }
  for (const [resource, normalise] of [['activities', normaliseActivity], ['centers', normaliseCenter], ['gallery', normaliseGallery]]) {
    if (pathname === `/api/${resource}` || pathname.startsWith(`/api/${resource}/`)) return handleResource(req, res, pathname, resource, normalise);
  }
  return sendError(res, 404, 'المسار المطلوب غير موجود.');
}

async function serveStatic(res, pathname) {
  const requested = pathname === '/' ? '/index.html' : pathname;
  const filePath = path.resolve(PUBLIC_DIR, `.${path.normalize(requested)}`);
  if (!filePath.startsWith(PUBLIC_DIR)) return sendError(res, 403, 'غير مسموح.');
  try {
    const file = await fs.readFile(filePath);
    const ext = path.extname(filePath).toLowerCase();
    res.writeHead(200, {
      'Content-Type': MIME_TYPES[ext] || 'application/octet-stream',
      'X-Content-Type-Options': 'nosniff',
      'Cache-Control': ext === '.html' ? 'no-cache' : 'public, max-age=3600'
    });
    res.end(file);
  } catch (error) {
    if (error.code === 'ENOENT') return sendError(res, 404, 'الصفحة غير موجودة.');
    throw error;
  }
}

async function main() {
  await ensureDataFiles();
  setInterval(() => {
    const now = Date.now();
    for (const [token, session] of sessions) if (session.expiresAt < now) sessions.delete(token);
  }, 15 * 60 * 1000).unref();
  const server = http.createServer(async (req, res) => {
    try {
      const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
      if (url.pathname.startsWith('/api/')) await handleApi(req, res, url);
      else await serveStatic(res, decodeURIComponent(url.pathname));
    } catch (error) {
      console.error(error);
      if (!res.headersSent) sendError(res, error.status || 500, error.message || 'حدث خطأ غير متوقع.');
      else res.end();
    }
  });
  server.listen(PORT, () => console.log(`ملتقى العلم والثقافية يعمل على http://localhost:${PORT}`));
}

main().catch((error) => { console.error(error); process.exit(1); });
