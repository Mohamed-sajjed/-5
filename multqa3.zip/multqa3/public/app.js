const state = { content: null, session: { authenticated: false, username: '' }, messages: [], activePanel: 'settings' };
const $ = (selector, scope = document) => scope.querySelector(selector);
const $$ = (selector, scope = document) => [...scope.querySelectorAll(selector)];

function escapeHtml(value = '') {
  return String(value).replace(/[&<>'"]/g, (character) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' })[character]);
}

function safeImage(value) {
  const source = String(value || '/assets/logo.png');
  return (source.startsWith('/') || /^https?:\/\//i.test(source)) ? source : '/assets/logo.png';
}

function safeLink(value) {
  try {
    const url = new URL(String(value));
    return ['http:', 'https:'].includes(url.protocol) ? url.href : '';
  } catch { return ''; }
}

async function api(path, options = {}) {
  const config = { credentials: 'same-origin', ...options, headers: { ...(options.body ? { 'Content-Type': 'application/json' } : {}), ...(options.headers || {}) } };
  const response = await fetch(path, config);
  let data = {};
  try { data = await response.json(); } catch { /* response handled below */ }
  if (!response.ok) throw new Error(data.error || 'تعذر تنفيذ العملية. حاول مرة أخرى.');
  return data;
}

function setStatus(element, message = '', type = '') {
  if (!element) return;
  element.textContent = message;
  element.className = `form-status ${type}`;
}

let toastTimer;
function toast(message, type = '') {
  const node = $('#toast');
  node.textContent = message;
  node.className = `toast show ${type}`;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { node.className = 'toast'; }, 3400);
}

function infoRow(icon, content, href = '') {
  if (!content) return '';
  const text = escapeHtml(content);
  return `<div class="contact-detail"><i>${icon}</i>${href ? `<a href="${escapeHtml(href)}" target="_blank" rel="noopener">${text}</a>` : `<span>${text}</span>`}</div>`;
}

function renderPublic() {
  if (!state.content) return;
  const { settings, activities = [], centers = [], gallery = [], contact = {} } = state.content;
  const logo = safeImage(settings.logo);
  document.title = settings.siteName;
  $('#metaDescription').content = `${settings.siteName}، ${settings.tagline}`;
  $('#metaOgTitle').content = settings.siteName;
  $('#metaOgDescription').content = `${settings.siteName}، ${settings.tagline}`;
  $('#metaOgImage').content = new URL(logo, window.location.origin).href;
  $('#canonicalUrl').href = window.location.href.split('#')[0];
  $('#organizationSchema').textContent = JSON.stringify({ '@context': 'https://schema.org', '@type': 'Organization', name: settings.siteName, description: settings.tagline, logo: new URL(logo, window.location.origin).href, url: window.location.origin });
  $('#headerLogo').src = logo; $('#heroLogo').src = logo; $('#footerLogo').src = logo;
  $('#headerName').textContent = settings.siteName; $('#footerName').textContent = settings.siteName;
  $('#headerTagline').textContent = settings.tagline; $('#footerTagline').textContent = settings.tagline;
  $('#heroTitle').textContent = settings.heroTitle; $('#heroText').textContent = settings.heroText;
  $('#heroArt').style.setProperty('--hero-image', `url("${safeImage(settings.heroImage).replace(/"/g, '%22')}")`);
  $('#activitiesGrid').innerHTML = activities.length ? activities.map((item) => `
    <article class="activity-card reveal">
      <img src="${escapeHtml(safeImage(item.image || logo))}" alt="" loading="lazy" />
      <div class="activity-content"><div class="activity-meta"><b>${escapeHtml(item.category)}</b><span>◷ ${escapeHtml(item.date)}</span></div><h3>${escapeHtml(item.title)}</h3><p>${escapeHtml(item.details)}</p></div>
    </article>`).join('') : '<div class="empty-state">ستُضاف الأنشطة قريبًا.</div>';
  $('#centersGrid').innerHTML = centers.length ? centers.map((item) => `
    <article class="center-card reveal"><div class="center-icon">⌂</div>${renderCenterImages(item.images, logo)}<h3>${escapeHtml(item.name)}</h3><span class="center-city">⌖ ${escapeHtml(item.city)}</span><p>${escapeHtml(item.details)}</p>${renderCenterVideos(item.videos)}<div class="center-info">${item.manager ? `<span>◉ المسؤول: ${escapeHtml(item.manager)}</span>` : ''}${item.hours ? `<span>◷ ${escapeHtml(item.hours)}</span>` : ''}${item.phone ? `<span>☎ ${escapeHtml(item.phone)}</span>` : ''}</div></article>`).join('') : '<div class="empty-state">ستُضاف المراكز قريبًا.</div>';
  $('#galleryGrid').innerHTML = gallery.length ? gallery.map((item) => `
    <article class="gallery-item reveal"><img src="${escapeHtml(safeImage(item.image || logo))}" alt="${escapeHtml(item.title)}" loading="lazy" /><div class="gallery-caption"><h3>${escapeHtml(item.title)}</h3>${item.caption ? `<p>${escapeHtml(item.caption)}</p>` : ''}</div></article>`).join('') : '<div class="empty-state">سيظهر معرض الصور هنا قريبًا.</div>';
  const map = safeLink(contact.mapUrl);
  const phoneHref = contact.phone ? `tel:${String(contact.phone).replace(/[^+\d]/g, '')}` : '';
  const whatsappDigits = String(contact.whatsapp || '').replace(/\D/g, '');
  $('#contactDetails').innerHTML = [
    infoRow('⌖', contact.address),
    infoRow('☎', contact.phone, phoneHref),
    infoRow('◉', contact.whatsapp, whatsappDigits ? `https://wa.me/${whatsappDigits}` : ''),
    infoRow('✉', contact.email, contact.email ? `mailto:${contact.email}` : ''),
    infoRow('◷', contact.workHours),
    map ? infoRow('↗', 'موقع المؤسسة على الخريطة', map) : ''
  ].join('');
}

function fillForm(form, values = {}) {
  $$('input, textarea', form).forEach((field) => {
    if (field.name && Object.prototype.hasOwnProperty.call(values, field.name)) field.value = values[field.name] ?? '';
  });
}

function renderAdmin() {
  if (!state.content) return;
  const { settings, activities = [], centers = [], gallery = [], contact = {} } = state.content;
  $('#adminLogo').src = safeImage(settings.logo);
  $('#adminUsername').textContent = state.session.username;
  fillForm($('#settingsForm'), settings);
  fillForm($('#contactForm'), contact);
  $('#accountForm').elements.username.value = state.session.username;
  $('#activitiesAdminList').innerHTML = activities.length ? activities.map((item) => adminItem('activity', item, item.title, item.details, item.image || settings.logo, `${item.category} · ${item.date}`)).join('') : emptyAdmin('لا توجد أنشطة حتى الآن. اضغط «نشاط جديد» لإضافة أول نشاط.');
  $('#centersAdminList').innerHTML = centers.length ? centers.map((item) => adminItem('center', item, item.name, item.details, item.images?.[0] || settings.logo, `${item.city}${item.manager ? ` · ${item.manager}` : ''}${item.images?.length ? ` · ${item.images.length} صور` : ''}`)).join('') : emptyAdmin('لا توجد مراكز مسجلة حتى الآن.');
  $('#galleryAdminList').innerHTML = gallery.length ? gallery.map((item) => adminItem('gallery', item, item.title, item.caption, item.image || settings.logo, 'صورة في المعرض')).join('') : emptyAdmin('لا توجد صور في المعرض حتى الآن.');
  $('#messageCount').textContent = state.messages.length || '';
  renderMessages();
}

function emptyAdmin(message) { return `<div class="admin-empty">${escapeHtml(message)}</div>`; }

function renderCenterImages(images = [], fallback = '/assets/logo.png') {
  const list = Array.isArray(images) && images.length ? images : [fallback];
  return `<div class="center-images">${list.slice(0, 6).map((image) => `<img src="${escapeHtml(safeImage(image))}" alt="" loading="lazy" />`).join('')}</div>`;
}

function videoMarkup(url) {
  try {
    const parsed = new URL(url, window.location.origin);
    const host = parsed.hostname.replace(/^www\./, '');
    if (host === 'youtube.com' || host === 'm.youtube.com' || host === 'youtu.be') {
      const id = host === 'youtu.be' ? parsed.pathname.slice(1) : parsed.searchParams.get('v');
      if (id) return `<iframe src="https://www.youtube.com/embed/${encodeURIComponent(id)}" title="فيديو المركز" loading="lazy" allowfullscreen></iframe>`;
    }
    if (host === 'vimeo.com') {
      const id = parsed.pathname.split('/').filter(Boolean).pop();
      if (/^\d+$/.test(id || '')) return `<iframe src="https://player.vimeo.com/video/${id}" title="فيديو المركز" loading="lazy" allowfullscreen></iframe>`;
    }
    return `<video controls preload="metadata" src="${escapeHtml(parsed.href)}"></video>`;
  } catch { return ''; }
}

function renderCenterVideos(videos = []) {
  if (!Array.isArray(videos) || !videos.length) return '';
  return `<div class="center-videos"><h4>فيديوهات المركز</h4>${videos.slice(0, 20).map(videoMarkup).join('')}</div>`;
}

function adminItem(type, item, title, description, image, meta) {
  return `<article class="admin-item"><img class="admin-item-image" src="${escapeHtml(safeImage(image))}" alt="" /><div class="admin-item-body"><h3>${escapeHtml(title)}</h3><p>${escapeHtml(description || 'لا يوجد وصف.')}</p><span class="admin-item-meta">${escapeHtml(meta)}</span></div><div class="admin-actions"><button class="mini-button" data-edit="${type}" data-id="${item.id}">تعديل</button><button class="mini-button delete" data-delete="${type}" data-id="${item.id}">حذف</button></div></article>`;
}

function formatDate(value) {
  try { return new Intl.DateTimeFormat('ar-IQ', { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(value)); }
  catch { return ''; }
}

function renderMessages() {
  const target = $('#messagesList');
  target.innerHTML = state.messages.length ? state.messages.map((message) => `
    <article class="message-card"><button class="mini-button delete" data-message-delete="${message.id}">حذف</button><h3>${escapeHtml(message.name)}</h3><div class="message-meta">${message.phone ? `<span>☎ ${escapeHtml(message.phone)}</span>` : ''}${message.email ? `<span>✉ ${escapeHtml(message.email)}</span>` : ''}<span>◷ ${escapeHtml(formatDate(message.createdAt))}</span></div><p>${escapeHtml(message.message)}</p></article>`).join('') : emptyAdmin('صندوق الوارد فارغ حاليًا.');
}

async function refreshContent() {
  state.content = await api('/api/content');
  renderPublic();
}

async function refreshMessages() {
  if (!state.session.authenticated) return;
  const data = await api('/api/messages');
  state.messages = data.messages || [];
}

function showAdmin(panel = 'settings') {
  if (!state.session.authenticated) return;
  $('#siteShell').classList.add('hidden');
  $('#adminArea').classList.remove('hidden');
  selectPanel(panel);
  renderAdmin();
}

function showSite() {
  $('#adminArea').classList.add('hidden');
  $('#siteShell').classList.remove('hidden');
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function selectPanel(name) {
  state.activePanel = name;
  $$('.admin-tab').forEach((button) => button.classList.toggle('active', button.dataset.panel === name));
  $$('.admin-panel').forEach((panel) => panel.classList.toggle('active', panel.id === `panel-${name}`));
  const selected = $(`.admin-tab[data-panel="${name}"]`);
  if (selected) $('#adminHeading').textContent = selected.childNodes[0].textContent.trim();
  $('#adminArea').classList.remove('menu-open');
}

function openEditor(type, id = '') {
  const form = $(`#${type}Form`);
  const groups = { activity: 'activities', center: 'centers', gallery: 'gallery' };
  const item = id ? state.content[groups[type]].find((record) => record.id === id) : null;
  form.reset();
  fillForm(form, item || {});
  form.elements.id.value = item?.id || '';
  if (type === 'center') {
    form.elements.images.value = JSON.stringify(item?.images || []);
    form.elements.videos.value = JSON.stringify(item?.videos || []);
    renderCenterImageList(form);
    renderCenterVideoList(form);
  }
  $('h3', form).textContent = item ? `تعديل ${type === 'activity' ? 'النشاط' : type === 'center' ? 'المركز' : 'الصورة'}` : `إضافة ${type === 'activity' ? 'نشاط' : type === 'center' ? 'مركز' : 'صورة'}`;
  if (!item && type === 'activity') form.elements.image.value = state.content.settings.logo;
  form.classList.remove('hidden');
  form.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

function closeEditor(type) {
  const form = $(`#${type}Form`);
  form.reset(); form.classList.add('hidden'); setStatus($('.form-status', form));
}

async function uploadImage(input) {
  const files = [...(input.files || [])];
  const file = files[0];
  if (!file) return;
  if (files.some((selectedFile) => selectedFile.size > 5 * 1024 * 1024)) { toast('حجم كل صورة يجب ألا يتجاوز 5 ميغابايت.', 'error'); input.value = ''; return; }
  const form = input.closest('form');
  const status = $('.form-status', form);
  setStatus(status, files.length > 1 ? 'جارٍ رفع الصور…' : 'جارٍ رفع الصورة…');
  try {
    const urls = [];
    for (const selectedFile of files) {
      const dataUrl = await new Promise((resolve, reject) => { const reader = new FileReader(); reader.onload = () => resolve(reader.result); reader.onerror = reject; reader.readAsDataURL(selectedFile); });
      const result = await api('/api/upload', { method: 'POST', body: JSON.stringify({ dataUrl }) });
      urls.push(result.url);
    }
    const target = form.elements[input.dataset.target];
    if (input.multiple) {
      const current = JSON.parse(target.value || '[]');
      target.value = JSON.stringify([...current, ...urls]);
      renderCenterImageList(form);
    } else target.value = urls[0];
    setStatus(status, 'تم رفع الصورة. اضغط حفظ لتطبيق التعديل.', 'success');
  } catch (error) { setStatus(status, error.message, 'error'); }
  finally { input.value = ''; }
}

function renderCenterImageList(form) {

  function renderCenterVideoList(form) {
    const target = $('[data-center-videos]', form);
    if (!target) return;
    let videos = [];
    try { videos = JSON.parse(form.elements.videos.value || '[]'); } catch { videos = []; }
    target.innerHTML = videos.length ? videos.map((video, index) => `<div class="center-video-row"><span>${escapeHtml(video)}</span><button type="button" class="mini-button delete" data-remove-center-video="${index}">حذف</button></div>`).join('') : '<small>لم تتم إضافة فيديوهات للمركز بعد.</small>';
  }
  const target = $('[data-center-images]', form);
  if (!target) return;
  let images = [];
  try { images = JSON.parse(form.elements.images.value || '[]'); } catch { images = []; }
  target.innerHTML = images.length ? images.map((image, index) => `<div class="center-image-preview"><img src="${escapeHtml(safeImage(image))}" alt="صورة المركز ${index + 1}" /><button type="button" class="mini-button delete" data-remove-center-image="${index}">حذف</button></div>`).join('') : '<small>لم تتم إضافة صور للمركز بعد.</small>';
}

async function submitItem(form, type) {
  const status = $('.form-status', form);
  const values = Object.fromEntries(new FormData(form).entries());
  const id = values.id; delete values.id;
  const plural = { activity: 'activities', center: 'centers', gallery: 'gallery' }[type];
  setStatus(status, 'جارٍ الحفظ…');
  try {
    await api(`/api/${plural}${id ? `/${encodeURIComponent(id)}` : ''}`, { method: id ? 'PUT' : 'POST', body: JSON.stringify(values) });
    await refreshContent(); await refreshMessages(); renderAdmin(); closeEditor(type);
    toast(id ? 'تم حفظ التعديلات بنجاح.' : 'تمت الإضافة بنجاح.', 'success');
  } catch (error) { setStatus(status, error.message, 'error'); }
}

async function deleteItem(type, id) {
  const labels = { activity: 'النشاط', center: 'المركز', gallery: 'الصورة' };
  if (!window.confirm(`هل تريد حذف ${labels[type]} نهائيًا؟`)) return;
  const plural = { activity: 'activities', center: 'centers', gallery: 'gallery' }[type];
  try {
    await api(`/api/${plural}/${encodeURIComponent(id)}`, { method: 'DELETE' });
    await refreshContent(); renderAdmin(); toast('تم الحذف بنجاح.', 'success');
  } catch (error) { toast(error.message, 'error'); }
}

function bindEvents() {
  $('#year').textContent = new Date().getFullYear();
  const navToggle = $('#navToggle');
  const mainNav = $('#mainNav');
  const setNavOpen = (open) => {
    mainNav.classList.toggle('open', open);
    navToggle.setAttribute('aria-expanded', String(open));
    navToggle.textContent = open ? '✕' : '☰';
    navToggle.setAttribute('aria-label', open ? 'إغلاق القائمة' : 'فتح القائمة');
    document.body.classList.toggle('nav-open-lock', open);
  };
  navToggle.addEventListener('click', (event) => {
    event.stopPropagation();
    setNavOpen(!mainNav.classList.contains('open'));
  });
  $$('#mainNav a').forEach((link) => link.addEventListener('click', () => setNavOpen(false)));
  document.addEventListener('click', (event) => {
    if (!mainNav.classList.contains('open')) return;
    if (mainNav.contains(event.target) || navToggle.contains(event.target)) return;
    setNavOpen(false);
  });
  document.addEventListener('keydown', (event) => { if (event.key === 'Escape') setNavOpen(false); });
  window.addEventListener('resize', () => { if (window.innerWidth > 850) setNavOpen(false); });
  $('#openLogin').addEventListener('click', () => $('#loginDialog').showModal());
  $$('[data-close-dialog]').forEach((button) => button.addEventListener('click', () => $('#loginDialog').close()));
  $('#loginDialog').addEventListener('click', (event) => { if (event.target === $('#loginDialog')) $('#loginDialog').close(); });
  $('#loginForm').addEventListener('submit', async (event) => {
    event.preventDefault(); const form = event.currentTarget; const status = $('#loginStatus'); const values = Object.fromEntries(new FormData(form).entries());
    setStatus(status, 'جارٍ التحقق…');
    try { const result = await api('/api/login', { method: 'POST', body: JSON.stringify(values) }); state.session = { authenticated: true, username: result.username }; await refreshMessages(); $('#loginDialog').close(); form.reset(); showAdmin(); toast('مرحبًا بك في لوحة الإدارة.', 'success'); }
    catch (error) { setStatus(status, error.message, 'error'); }
  });
  $('#messageForm').addEventListener('submit', async (event) => {
    event.preventDefault(); const form = event.currentTarget; const status = $('#messageStatus');
    setStatus(status, 'جارٍ إرسال رسالتك…');
    try { await api('/api/messages', { method: 'POST', body: JSON.stringify(Object.fromEntries(new FormData(form).entries())) }); form.reset(); setStatus(status, 'تم إرسال رسالتك بنجاح. شكرًا لتواصلك معنا.', 'success'); }
    catch (error) { setStatus(status, error.message, 'error'); }
  });
  $$('.admin-tab').forEach((button) => button.addEventListener('click', () => selectPanel(button.dataset.panel)));
  $('#adminMenuToggle').addEventListener('click', () => $('#adminArea').classList.toggle('menu-open'));
  $('#returnSite').addEventListener('click', showSite);
  $('#logoutButton').addEventListener('click', async () => {
    try { await api('/api/logout', { method: 'POST' }); } catch { /* clear local UI even if server was restarted */ }
    state.session = { authenticated: false, username: '' }; state.messages = []; showSite(); toast('تم تسجيل الخروج.');
  });
  $('#settingsForm').addEventListener('submit', async (event) => {
    event.preventDefault(); const form = event.currentTarget; const status = $('.form-status', form); setStatus(status, 'جارٍ الحفظ…');
    try { await api('/api/settings', { method: 'PUT', body: JSON.stringify(Object.fromEntries(new FormData(form).entries())) }); await refreshContent(); renderAdmin(); setStatus(status, 'تم حفظ إعدادات الواجهة.', 'success'); toast('تم تحديث الواجهة.', 'success'); }
    catch (error) { setStatus(status, error.message, 'error'); }
  });
  $('#contactForm').addEventListener('submit', async (event) => {
    event.preventDefault(); const form = event.currentTarget; const status = $('.form-status', form); setStatus(status, 'جارٍ الحفظ…');
    try { await api('/api/contact', { method: 'PUT', body: JSON.stringify(Object.fromEntries(new FormData(form).entries())) }); await refreshContent(); renderAdmin(); setStatus(status, 'تم حفظ بيانات التواصل.', 'success'); toast('تم تحديث بيانات التواصل.', 'success'); }
    catch (error) { setStatus(status, error.message, 'error'); }
  });
  $('#accountForm').addEventListener('submit', async (event) => {
    event.preventDefault(); const form = event.currentTarget; const status = $('.form-status', form); setStatus(status, 'جارٍ تحديث الحساب…');
    try { const result = await api('/api/account', { method: 'PUT', body: JSON.stringify(Object.fromEntries(new FormData(form).entries())) }); state.session.username = result.username; form.elements.currentPassword.value = ''; form.elements.newPassword.value = ''; renderAdmin(); setStatus(status, 'تم تحديث بيانات الدخول بنجاح.', 'success'); toast('تم تحديث حساب الأدمن.', 'success'); }
    catch (error) { setStatus(status, error.message, 'error'); }
  });
  ['activity', 'center', 'gallery'].forEach((type) => {
    $(`#${type}Form`).addEventListener('submit', (event) => { event.preventDefault(); submitItem(event.currentTarget, type); });
    $(`[data-cancel-form="${type}"]`).addEventListener('click', () => closeEditor(type));
  });
  $$('[data-open-form]').forEach((button) => button.addEventListener('click', () => openEditor(button.dataset.openForm)));
  document.addEventListener('change', (event) => { if (event.target.matches('.image-upload')) uploadImage(event.target); });
  $('.admin-content').addEventListener('click', async (event) => {
    const removeCenterImage = event.target.closest('[data-remove-center-image]');
    const addCenterVideo = event.target.closest('[data-add-center-video]');
    const removeCenterVideo = event.target.closest('[data-remove-center-video]');
    const edit = event.target.closest('[data-edit]');
    const remove = event.target.closest('[data-delete]');
    const removeMessage = event.target.closest('[data-message-delete]');
    if (removeCenterImage) {
      const form = removeCenterImage.closest('form');
      const images = JSON.parse(form.elements.images.value || '[]');
      images.splice(Number(removeCenterImage.dataset.removeCenterImage), 1);
      form.elements.images.value = JSON.stringify(images);
      renderCenterImageList(form);
      return;
    }
    if (addCenterVideo) {
      const form = addCenterVideo.closest('form');
      const input = $('[data-center-video-input]', form);
      const value = input.value.trim();
      if (!value || !/^(https?:\/\/|\/)/i.test(value)) { setStatus($('.form-status', form), 'أدخل رابط فيديو صحيحًا يبدأ بـ http أو https.', 'error'); return; }
      const videos = JSON.parse(form.elements.videos.value || '[]');
      if (videos.length >= 20) { setStatus($('.form-status', form), 'يمكن إضافة 20 فيديو للمركز كحد أقصى.', 'error'); return; }
      videos.push(value); form.elements.videos.value = JSON.stringify(videos); input.value = ''; renderCenterVideoList(form); return;
    }
    if (removeCenterVideo) {
      const form = removeCenterVideo.closest('form');
      const videos = JSON.parse(form.elements.videos.value || '[]');
      videos.splice(Number(removeCenterVideo.dataset.removeCenterVideo), 1);
      form.elements.videos.value = JSON.stringify(videos); renderCenterVideoList(form); return;
    }
    if (edit) openEditor(edit.dataset.edit, edit.dataset.id);
    if (remove) deleteItem(remove.dataset.delete, remove.dataset.id);
    if (removeMessage) {
      if (!window.confirm('هل تريد حذف هذه الرسالة نهائيًا؟')) return;
      try { await api(`/api/messages/${encodeURIComponent(removeMessage.dataset.messageDelete)}`, { method: 'DELETE' }); await refreshMessages(); renderAdmin(); toast('تم حذف الرسالة.', 'success'); }
      catch (error) { toast(error.message, 'error'); }
    }
  });
}

async function init() {
  bindEvents();
  try {
    const [content, session] = await Promise.all([api('/api/content'), api('/api/session')]);
    state.content = content; state.session = session; renderPublic();
    if (state.session.authenticated) { await refreshMessages(); renderAdmin(); }
  } catch (error) {
    console.error(error);
    toast('تعذر تحميل الموقع. تأكد من تشغيل الخادم المحلي.', 'error');
  }
}

init();
