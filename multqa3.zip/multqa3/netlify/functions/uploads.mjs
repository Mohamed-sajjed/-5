/*
 * تقديم الصور التي يرفعها الأدمن من لوحة الإدارة. بما أن Netlify Functions
 * لا تكتب على قرص دائم، الصور تُخزَّن في Netlify Blobs عبر /api/upload
 * (راجع api.mjs) وتُقرأ من هنا عند زيارة الرابط /uploads/<اسم الملف>.
 */
import { uploadsStore } from './_lib.mjs';

export default async (req) => {
  const { pathname } = new URL(req.url);
  const filename = decodeURIComponent(pathname.replace(/^\/uploads\//, ''));

  if (!filename || filename.includes('/') || filename.includes('..')) {
    return new Response('غير موجود', { status: 404 });
  }

  const result = await uploadsStore().getWithMetadata(filename, { type: 'arrayBuffer' });
  if (!result) return new Response('الصورة غير موجودة', { status: 404 });

  return new Response(result.data, {
    status: 200,
    headers: {
      'Content-Type': result.metadata?.contentType || 'application/octet-stream',
      'Cache-Control': 'public, max-age=31536000, immutable'
    }
  });
};

export const config = { path: '/uploads/*' };
