/*
 * أدوات مشتركة تُستخدم من دالتي api.mjs و uploads.mjs.
 * هذا الملف يبدأ اسمه بـ "_" لكي تتجاهله Netlify ولا تنشره كدالة مستقلة.
 *
 * لماذا Netlify Blobs بدل ملفات data/*.json؟
 * لأن Netlify Functions تعمل في بيئة "serverless" مؤقتة القرص، أي أن أي
 * كتابة على نظام الملفات المحلي تختفي فور انتهاء الطلب ولا تُشارك بين
 * الطلبات التالية. لذلك ننقل تخزين المحتوى وحساب الأدمن والصور المرفوعة
 * إلى Netlify Blobs، وهو تخزين دائم مدمج في منصة Netlify بلا إعداد إضافي.
 */
import { getStore } from '@netlify/blobs';
import crypto from 'node:crypto';

export const contentStore = () => getStore('site-content');
export const adminStore = () => getStore('site-admin');
export const uploadsStore = () => getStore('site-uploads');

const SESSION_TTL_MS = 8 * 60 * 60 * 1000;
// يُفضّل ضبط متغير بيئة SESSION_SECRET من إعدادات الموقع في Netlify
// (Site configuration → Environment variables). القيمة الافتراضية هنا
// موجودة فقط حتى لا يتعطل الموقع إن نسي أحد ضبطها، لكنها ليست آمنة للإنتاج.
const SESSION_SECRET = process.env.SESSION_SECRET || 'multaqa-alilm-insecure-default-secret-change-me';
const INITIAL_ADMIN_USERNAME = process.env.ADMIN_USERNAME || 'sadiq1988';
const INITIAL_ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'sadiq\\@1988';

export function defaultContent() {
  return {
    settings: {
      siteName: 'مؤسسة ملتقى العلم والثقافية',
      tagline: 'معًا نصنع أثرًا معرفيًا وثقافيًا مستدامًا',
      heroTitle: 'العلم والثقافة… مساحة تلتقي فيها الأفكار',
      heroText: 'نعمل على بناء مجتمع واعٍ ومبدع عبر برامج معرفية وأنشطة ثقافية ومراكز قريبة من الناس.',
      logo: '/assets/logo.png',
      heroImage: '/assets/logo.png'
    },
    activities: [
      {
        id: crypto.randomUUID(),
        title: 'الملتقى الثقافي الأسبوعي',
        details: 'جلسة حوارية مفتوحة تجمع المهتمين بالمعرفة والفكر والثقافة.',
        date: 'كل يوم سبت',
        category: 'ثقافي',
        image: '/assets/logo.png'
      },
      {
        id: crypto.randomUUID(),
        title: 'برنامج القراءة الواعية',
        details: 'رحلة قراءة جماعية تناقش الكتب المؤثرة وتحوّل الأفكار إلى ممارسة.',
        date: 'شهريًا',
        category: 'معرفي',
        image: '/assets/logo.png'
      },
      {
        id: crypto.randomUUID(),
        title: 'ورش مهارات الشباب',
        details: 'ورش عملية في التواصل والقيادة والتخطيط لصناعة مبادرات مجتمعية ناجحة.',
        date: 'حسب الإعلان',
        category: 'تدريبي',
        image: '/assets/logo.png'
      }
    ],
    centers: [
      {
        id: crypto.randomUUID(),
        name: 'المركز الثقافي الرئيس',
        city: 'يُحدَّد من لوحة الإدارة',
        details: 'مساحة للقراءة والندوات والبرامج التدريبية واللقاءات المجتمعية.',
        manager: 'إدارة المؤسسة',
        hours: 'السبت–الخميس | 9 ص – 6 م',
        phone: '',
        images: [],
        videos: []
      }
    ],
    gallery: [
      {
        id: crypto.randomUUID(),
        title: 'هوية المؤسسة',
        caption: 'شعار مؤسسة ملتقى العلم والثقافية',
        image: '/assets/logo.png'
      }
    ],
    contact: {
      address: 'أضف عنوان المؤسسة من لوحة الإدارة',
      phone: '',
      whatsapp: '',
      email: '',
      workHours: 'السبت–الخميس | 9 ص – 6 م',
      mapUrl: ''
    },
    messages: []
  };
}

export async function getContent() {
  const store = contentStore();
  const content = await store.get('content', { type: 'json' });
  if (content) return content;
  const initial = defaultContent();
  await store.setJSON('content', initial);
  return initial;
}

export async function saveContent(content) {
  await contentStore().setJSON('content', content);
}

function hashPassword(password, salt) {
  return crypto.scryptSync(password, salt, 64).toString('hex');
}

export async function getAdmin() {
  const store = adminStore();
  const admin = await store.get('admin', { type: 'json' });
  if (admin) return admin;
  const salt = crypto.randomBytes(16).toString('hex');
  const initial = {
    username: INITIAL_ADMIN_USERNAME,
    salt,
    passwordHash: hashPassword(INITIAL_ADMIN_PASSWORD, salt)
  };
  await store.setJSON('admin', initial);
  return initial;
}

export async function saveAdmin(admin) {
  await adminStore().setJSON('admin', admin);
}

export function hashPasswordWithSalt(password, salt) {
  return hashPassword(password, salt);
}

export function secureEqual(first, second) {
  const a = Buffer.from(first, 'hex');
  const b = Buffer.from(second, 'hex');
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

// ---- جلسات موقّعة بلا حالة (بدون حفظ في الذاكرة) ----
// بما أن كل استدعاء لدالة Netlify قد يعمل على نسخة مختلفة تمامًا، لا يمكن
// الاعتماد على Map في الذاكرة كما في server.js المحلي. بدلاً من ذلك نوقّع
// بيانات الجلسة (اسم المستخدم + وقت الانتهاء) داخل الكوكي نفسها باستخدام
// HMAC-SHA256، ونتحقق من التوقيع في كل طلب.
function sign(payload) {
  return crypto.createHmac('sha256', SESSION_SECRET).update(payload).digest('base64url');
}

export function createSessionToken(username) {
  const payload = JSON.stringify({ username, exp: Date.now() + SESSION_TTL_MS });
  const encoded = Buffer.from(payload, 'utf8').toString('base64url');
  return `${encoded}.${sign(encoded)}`;
}

export function verifySessionToken(token) {
  if (!token || typeof token !== 'string' || !token.includes('.')) return null;
  const [encoded, signature] = token.split('.');
  if (!encoded || !signature) return null;
  let expected;
  try { expected = sign(encoded); } catch { return null; }
  const a = Buffer.from(signature);
  const b = Buffer.from(expected);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;
  try {
    const payload = JSON.parse(Buffer.from(encoded, 'base64url').toString('utf8'));
    if (!payload.exp || payload.exp < Date.now()) return null;
    return payload;
  } catch { return null; }
}

export function parseCookies(req) {
  const header = req.headers.get('cookie') || '';
  return Object.fromEntries(header.split(';').filter(Boolean).map((part) => {
    const index = part.indexOf('=');
    return [part.slice(0, index).trim(), decodeURIComponent(part.slice(index + 1))];
  }));
}

export function getSession(req) {
  const token = parseCookies(req).session;
  return verifySessionToken(token);
}

export function sessionCookie(token, { clear = false, secure = true } = {}) {
  const maxAge = clear ? 0 : Math.floor(SESSION_TTL_MS / 1000);
  const secureFlag = secure ? ' Secure;' : '';
  return `session=${encodeURIComponent(token || '')}; HttpOnly;${secureFlag} SameSite=Strict; Path=/; Max-Age=${maxAge}`;
}

// ---- استجابات مساعدة ----
export function json(status, body, headers = {}) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...headers }
  });
}

export function errorResponse(status, message) {
  return json(status, { error: message });
}

export class HttpError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}

// ---- تحقق من صحة الحقول (مطابق لمنطق server.js المحلي) ----
export function text(value, field, max = 2000, required = false) {
  const result = String(value ?? '').trim();
  if (required && !result) throw new HttpError(400, `حقل «${field}» مطلوب.`);
  if (result.length > max) throw new HttpError(400, `حقل «${field}» أطول من اللازم.`);
  return result;
}

export function imageUrl(value) {
  const result = text(value, 'الصورة', 500, false);
  if (result && !result.startsWith('/') && !/^https?:\/\//i.test(result)) {
    throw new HttpError(400, 'رابط الصورة غير صالح.');
  }
  return result;
}

export function imageList(value) {
  let images = value;
  if (typeof images === 'string') {
    try { images = JSON.parse(images || '[]'); } catch { images = []; }
  }
  if (!Array.isArray(images)) return [];
  if (images.length > 30) throw new HttpError(400, 'يمكن إضافة 30 صورة للمركز كحد أقصى.');
  return images.map((image) => imageUrl(image)).filter(Boolean);
}

export function videoList(value) {
  let videos = value;
  if (typeof videos === 'string') {
    try { videos = JSON.parse(videos || '[]'); } catch { videos = []; }
  }
  if (!Array.isArray(videos)) return [];
  if (videos.length > 20) throw new HttpError(400, 'يمكن إضافة 20 فيديو للمركز كحد أقصى.');
  return videos.map((video) => {
    const result = text(video, 'رابط الفيديو', 500, false);
    if (result && !result.startsWith('/') && !/^https?:\/\//i.test(result)) {
      throw new HttpError(400, 'رابط الفيديو غير صالح.');
    }
    return result;
  }).filter(Boolean);
}

export function externalUrl(value, field) {
  const result = text(value, field, 500);
  if (!result) return '';
  try {
    const url = new URL(result);
    if (!['http:', 'https:'].includes(url.protocol)) throw new Error();
    return url.href;
  } catch {
    throw new HttpError(400, `حقل «${field}» يجب أن يكون رابطًا يبدأ بـ http أو https.`);
  }
}

export function normaliseActivity(body) {
  return {
    title: text(body.title, 'عنوان النشاط', 120, true),
    details: text(body.details, 'وصف النشاط', 1200, true),
    date: text(body.date, 'موعد النشاط', 100, true),
    category: text(body.category, 'التصنيف', 60, true),
    image: imageUrl(body.image)
  };
}

export function normaliseCenter(body) {
  return {
    name: text(body.name, 'اسم المركز', 120, true),
    city: text(body.city, 'المدينة أو الموقع', 120, true),
    details: text(body.details, 'وصف المركز', 1200, true),
    manager: text(body.manager, 'المسؤول', 120),
    hours: text(body.hours, 'ساعات العمل', 120),
    phone: text(body.phone, 'الهاتف', 60),
    images: imageList(body.images),
    videos: videoList(body.videos)
  };
}

export function normaliseGallery(body) {
  return {
    title: text(body.title, 'عنوان الصورة', 120, true),
    caption: text(body.caption, 'وصف الصورة', 500),
    image: imageUrl(body.image) || '/assets/logo.png'
  };
}

export function normaliseSettings(body) {
  return {
    siteName: text(body.siteName, 'اسم المؤسسة', 120, true),
    tagline: text(body.tagline, 'العبارة المختصرة', 180, true),
    heroTitle: text(body.heroTitle, 'عنوان الواجهة', 180, true),
    heroText: text(body.heroText, 'نص الواجهة', 1000, true),
    logo: imageUrl(body.logo) || '/assets/logo.png',
    heroImage: imageUrl(body.heroImage) || '/assets/logo.png'
  };
}

export function normaliseContact(body) {
  return {
    address: text(body.address, 'العنوان', 300),
    phone: text(body.phone, 'الهاتف', 60),
    whatsapp: text(body.whatsapp, 'واتساب', 60),
    email: text(body.email, 'البريد الإلكتروني', 160),
    workHours: text(body.workHours, 'ساعات العمل', 160),
    mapUrl: externalUrl(body.mapUrl, 'رابط الخريطة')
  };
}
