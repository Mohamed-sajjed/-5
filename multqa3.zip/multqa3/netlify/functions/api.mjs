/*
 * دالة Netlify واحدة تخدم كل مسارات /api/* بدلاً من خادم server.js التقليدي.
 * تُستدعى تلقائيًا لأي طلب يبدأ بـ /api/ بفضل إعداد "path" أدناه، بلا حاجة
 * لأي تحويلات (redirects) داخل netlify.toml.
 */
import crypto from 'node:crypto';
import {
  getContent, saveContent, getAdmin, saveAdmin,
  hashPasswordWithSalt, secureEqual,
  createSessionToken, getSession, sessionCookie,
  json, errorResponse, HttpError,
  text, uploadsStore,
  normaliseActivity, normaliseCenter, normaliseGallery, normaliseSettings, normaliseContact
} from './_lib.mjs';

const MAX_JSON_BYTES = 7 * 1024 * 1024;

async function readBody(req) {
  const raw = await req.text();
  if (raw.length > MAX_JSON_BYTES) throw new HttpError(413, 'الطلب كبير جدًا. الحد الأقصى للصورة 5 ميغابايت.');
  if (!raw) return {};
  try { return JSON.parse(raw); } catch { throw new HttpError(400, 'بيانات الطلب غير صالحة.'); }
}

function requireAdmin(req) {
  const session = getSession(req);
  if (!session) throw new HttpError(401, 'يجب تسجيل الدخول كمسؤول أولًا.');
  return session;
}

async function handleUpload(req) {
  requireAdmin(req);
  const body = await readBody(req);
  const dataUrl = text(body.dataUrl, 'ملف الصورة', MAX_JSON_BYTES, true);
  const match = dataUrl.match(/^data:(image\/(?:png|jpeg|webp|gif));base64,([A-Za-z0-9+/=]+)$/);
  if (!match) throw new HttpError(400, 'يُسمح فقط بصور PNG أو JPG أو WEBP أو GIF.');
  const buffer = Buffer.from(match[2], 'base64');
  if (!buffer.length || buffer.length > 5 * 1024 * 1024) throw new HttpError(413, 'حجم الصورة يجب ألا يتجاوز 5 ميغابايت.');
  const extension = { 'image/png': 'png', 'image/jpeg': 'jpg', 'image/webp': 'webp', 'image/gif': 'gif' }[match[1]];
  const filename = `${Date.now()}-${crypto.randomUUID().slice(0, 8)}.${extension}`;
  await uploadsStore().set(filename, buffer, { metadata: { contentType: match[1] } });
  return json(201, { url: `/uploads/${filename}` });
}

async function handleResource(req, pathname, resource, normalise) {
  requireAdmin(req);
  const base = `/api/${resource}`;
  const rest = pathname.slice(base.length).replace(/^\//, '');
  const content = await getContent();
  if (!Array.isArray(content[resource])) content[resource] = [];

  if (req.method === 'POST' && !rest) {
    const record = { id: crypto.randomUUID(), ...normalise(await readBody(req)) };
    content[resource].unshift(record);
    await saveContent(content);
    return json(201, { item: record });
  }
  const id = decodeURIComponent(rest);
  const index = content[resource].findIndex((item) => item.id === id);
  if (index < 0) return errorResponse(404, 'العنصر المطلوب غير موجود.');
  if (req.method === 'PUT') {
    const record = { id, ...normalise(await readBody(req)) };
    content[resource][index] = record;
    await saveContent(content);
    return json(200, { item: record });
  }
  if (req.method === 'DELETE') {
    content[resource].splice(index, 1);
    await saveContent(content);
    return json(200, { ok: true });
  }
  return errorResponse(405, 'طريقة الطلب غير مدعومة.');
}

async function router(req, pathname) {
  const isSecure = new URL(req.url).protocol === 'https:' || req.headers.get('x-forwarded-proto') === 'https';

  if (req.method === 'GET' && pathname === '/api/content') {
    const { messages, ...publicContent } = await getContent();
    return json(200, publicContent);
  }

  if (req.method === 'GET' && pathname === '/api/session') {
    const session = getSession(req);
    return json(200, { authenticated: Boolean(session), username: session?.username || '' });
  }

  if (req.method === 'POST' && pathname === '/api/login') {
    const { username, password } = await readBody(req);
    const admin = await getAdmin();
    const valid = text(username, 'اسم المستخدم', 60, true) === admin.username
      && secureEqual(hashPasswordWithSalt(String(password ?? ''), admin.salt), admin.passwordHash);
    if (!valid) return errorResponse(401, 'اسم المستخدم أو كلمة المرور غير صحيحة.');
    const token = createSessionToken(admin.username);
    return json(200, { ok: true, username: admin.username }, { 'Set-Cookie': sessionCookie(token, { secure: isSecure }) });
  }

  if (req.method === 'POST' && pathname === '/api/logout') {
    return json(200, { ok: true }, { 'Set-Cookie': sessionCookie('', { clear: true, secure: isSecure }) });
  }

  if (req.method === 'POST' && pathname === '/api/upload') return handleUpload(req);

  if (req.method === 'PUT' && pathname === '/api/settings') {
    requireAdmin(req);
    const content = await getContent();
    content.settings = normaliseSettings(await readBody(req));
    await saveContent(content);
    return json(200, { settings: content.settings });
  }

  if (req.method === 'PUT' && pathname === '/api/contact') {
    requireAdmin(req);
    const content = await getContent();
    content.contact = normaliseContact(await readBody(req));
    await saveContent(content);
    return json(200, { contact: content.contact });
  }

  if (req.method === 'POST' && pathname === '/api/messages') {
    const body = await readBody(req);
    const message = {
      id: crypto.randomUUID(),
      name: text(body.name, 'الاسم', 100, true),
      phone: text(body.phone, 'الهاتف', 60),
      email: text(body.email, 'البريد الإلكتروني', 160),
      message: text(body.message, 'الرسالة', 2000, true),
      createdAt: new Date().toISOString()
    };
    const content = await getContent();
    content.messages = Array.isArray(content.messages) ? content.messages : [];
    content.messages.unshift(message);
    await saveContent(content);
    return json(201, { ok: true });
  }

  if (pathname === '/api/messages') {
    requireAdmin(req);
    const content = await getContent();
    if (req.method === 'GET') return json(200, { messages: content.messages || [] });
    return errorResponse(405, 'طريقة الطلب غير مدعومة.');
  }

  if (req.method === 'DELETE' && pathname.startsWith('/api/messages/')) {
    requireAdmin(req);
    const id = decodeURIComponent(pathname.slice('/api/messages/'.length));
    const content = await getContent();
    const index = (content.messages || []).findIndex((item) => item.id === id);
    if (index < 0) return errorResponse(404, 'الرسالة غير موجودة.');
    content.messages.splice(index, 1);
    await saveContent(content);
    return json(200, { ok: true });
  }

  if (req.method === 'PUT' && pathname === '/api/account') {
    const session = requireAdmin(req);
    const body = await readBody(req);
    const admin = await getAdmin();
    const oldHash = hashPasswordWithSalt(String(body.currentPassword ?? ''), admin.salt);
    if (!secureEqual(oldHash, admin.passwordHash)) return errorResponse(401, 'كلمة المرور الحالية غير صحيحة.');
    const username = text(body.username, 'اسم المستخدم', 60, true);
    if (!/^[A-Za-z0-9_.-]{3,60}$/.test(username)) return errorResponse(400, 'استخدم حروفًا إنجليزية أو أرقامًا أو . _ - في اسم المستخدم.');
    const newPassword = text(body.newPassword, 'كلمة المرور الجديدة', 160, true);
    if (newPassword.length < 8) return errorResponse(400, 'كلمة المرور الجديدة يجب أن تكون 8 أحرف على الأقل.');
    const salt = crypto.randomBytes(16).toString('hex');
    await saveAdmin({ username, salt, passwordHash: hashPasswordWithSalt(newPassword, salt) });
    const token = createSessionToken(username);
    return json(200, { ok: true, username }, { 'Set-Cookie': sessionCookie(token, { secure: isSecure }) });
  }

  for (const [resource, normalise] of [['activities', normaliseActivity], ['centers', normaliseCenter], ['gallery', normaliseGallery]]) {
    if (pathname === `/api/${resource}` || pathname.startsWith(`/api/${resource}/`)) return handleResource(req, pathname, resource, normalise);
  }

  return errorResponse(404, 'المسار المطلوب غير موجود.');
}

export default async (req) => {
  try {
    const { pathname } = new URL(req.url);
    return await router(req, pathname);
  } catch (error) {
    if (error instanceof HttpError) return errorResponse(error.status, error.message);
    console.error(error);
    return errorResponse(500, 'حدث خطأ غير متوقع.');
  }
};

export const config = { path: '/api/*' };
